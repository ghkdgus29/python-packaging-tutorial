# Example Package

This is a simple example package.  <br>
Based on the packaging tutorial from the [official Python docs](https://packaging.python.org/en/latest/tutorials/packaging-projects/).
